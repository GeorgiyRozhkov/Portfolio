export { default } from "./headline";
