export { default } from "./button.vue";
