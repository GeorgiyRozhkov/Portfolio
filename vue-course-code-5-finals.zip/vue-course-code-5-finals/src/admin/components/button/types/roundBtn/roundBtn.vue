<template>
  <button v-on="$listeners" type="submit" data-text="+" class="round-button-component"></button>
</template>
<style lang="postcss" scoped src="./roundBtn.pcss"></style>